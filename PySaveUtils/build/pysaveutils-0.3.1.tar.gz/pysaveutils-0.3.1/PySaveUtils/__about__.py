"""Метаданные пакета `PySaveUtils`."""

__version__ = "0.3.1"

